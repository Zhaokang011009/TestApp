package com.example.testapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import coil.load
import com.example.testapp.databinding.FragmentDetailBinding
import com.example.testapp.util.SharedViewModel

class DetailFragment : Fragment() {
    private lateinit var binding: FragmentDetailBinding
    private val nav by lazy { findNavController() }
    private val movieVM: SharedViewModel by activityViewModels()
    private val movieID by lazy { requireArguments().getString("id") ?: ""}
    private val movieAuthor by lazy { requireArguments().getString("author") ?: ""}
    private val posterID by lazy { requireArguments().getString("photo") ?: ""}


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentDetailBinding.inflate(inflater, container, false)

        binding.imgDetail.load(posterID) { placeholder(R.drawable.loading_ani) }
        binding.txtMovieIDInput.text = movieID
        binding.txtMovieAuthorInput.text = movieAuthor

        return binding.root
    }
}