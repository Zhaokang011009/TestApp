package com.example.testapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.testapp.databinding.FragmentMovieListBinding
import com.example.testapp.util.MovieAdapter
import com.example.testapp.util.SharedViewModel

class MovieListFragment : Fragment() {
    private lateinit var binding: FragmentMovieListBinding
    private val nav by lazy { findNavController() }
    private val movieVM: SharedViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentMovieListBinding.inflate(inflater, container, false)

        val adapter = MovieAdapter(){holder, movie ->
            holder.root.setOnClickListener{
                nav.navigate(R.id.detailFragment, bundleOf("id" to movie.id, "author" to movie.author, "photo" to movie.photo))
            }
        }

        binding.rvMovieList.adapter = adapter
        movieVM.movies.observe(viewLifecycleOwner){movies -> adapter.submitList(movies)}

        binding.swipeContainer.setOnRefreshListener {
            binding.rvMovieList.adapter = null
            binding.rvMovieList.adapter = adapter
            movieVM.movies.observe(viewLifecycleOwner){movies -> adapter.submitList(movies)}
            binding.swipeContainer.isRefreshing = false
        }

        return binding.root
    }
}
