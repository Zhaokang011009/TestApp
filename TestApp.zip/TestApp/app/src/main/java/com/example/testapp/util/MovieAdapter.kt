package com.example.testapp.util

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.testapp.R

class MovieAdapter (
    // Function parameter or callback function
    val fn: (ViewHolder, Movie) -> Unit = { _, _ -> }
) : ListAdapter<Movie, MovieAdapter.ViewHolder>(DiffCallback) {

    // Static member
    companion object DiffCallback : DiffUtil.ItemCallback<Movie>() {
        override fun areItemsTheSame(a: Movie, b: Movie)    = a.id == b.id
        override fun areContentsTheSame(a: Movie, b: Movie) = a == b
    }

    // Inner class
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val root = view
        val imgMovie: ImageView = view.findViewById(R.id.imgMovie)
        val txtMovieTitle: TextView = view.findViewById(R.id.txtMovieTitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.movie_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.imgMovie.load(item.photo) { placeholder(R.drawable.loading_ani) }
        holder.txtMovieTitle.text = item.author

        fn(holder, item)
    }
}